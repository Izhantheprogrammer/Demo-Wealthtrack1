import sqlite3
import os

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

DB_PATH = os.path.join(os.getcwd(), 'db', 'wealthtrack.db')
@app.route('/')
def homepage():
    return render_template("homepage_wealthtrack.html")
# Module 2: Add Income and Expense Module

# @app.route('/add_expense', methods=['GET', 'POST'])
# def add_expense():
#     if request.method == 'POST':
#         # form handling logic here
#         pass
#     return render_template("add_expense.html")

# @app.route('/add_income', methods=['GET', 'POST'])
# def add_income():
#     if request.method == 'POST':
#         pass
#     return render_template("add_income.html")

@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    if request.method == 'POST':
        category = request.form['category']
        amount = request.form['amount']
        date = request.form['date']
        # note = request.form['note']
        note = request.form.get('note', '')


        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO transactions (type, category, amount, date, note) VALUES (?, ?, ?, ?, ?)",
                       ('expense', category, amount, date, note))
        conn.commit()
        conn.close()

        return redirect(url_for('view_transactions'))

    return render_template("add_expense.html")

# @app.route('/add-expense', methods=['GET', 'POST'])
@app.route('/add_income', methods=['GET', 'POST'])
def add_income():
    if request.method == 'POST':
        category = request.form['category']
        amount = request.form['amount']
        date = request.form['date']
        note = request.form['note']

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO transactions (type, category, amount, date, note) VALUES (?, ?, ?, ?, ?)",
                       ('income', category, amount, date, note))
        conn.commit()
        conn.close()

        return redirect(url_for('view_transactions'))

    return render_template("add_income.html")

# @app.route('/edit_transaction', methods=['GET', 'POST'])
# def edit_transaction():
#     if request.method == 'POST':
#         pass
#     return render_template("edit_transaction.html")

@app.route('/edit_transaction', methods=['GET', 'POST'])
def edit_transaction():
    if request.method == 'POST':
        transaction_id = request.form['transaction_id']
        type_ = request.form['type']
        category = request.form['category']
        amount = request.form['amount']
        date = request.form['date']
        note = request.form.get('note', '')

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE transactions
            SET type = ?, category = ?, amount = ?, date = ?, note = ?
            WHERE id = ?
        """, (type_, category, amount, date, note, transaction_id))
        conn.commit()
        conn.close()

        return redirect(url_for('view_transactions'))

    return render_template("edit_transaction.html")



# @app.route('/delete_transaction', methods=['GET', 'POST'])
# def delete_transaction():
#     if request.method == 'POST':
#         pass
#     return render_template("delete_transaction.html")

@app.route('/delete_transaction', methods=['GET', 'POST'])
def delete_transaction():
    if request.method == 'POST':
        transaction_id = request.form['transaction_id']
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))
            conn.commit()
            conn.close()
            return render_template("delete_transaction.html", success=True)
        except Exception as e:
            return render_template("delete_transaction.html", error=str(e))

    return render_template("delete_transaction.html")



# @app.route('/view_transactions')
# def view_transactions():
#     return render_template("view_transactions.html")

@app.route('/view_transactions')
def view_transactions():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, type, category, amount, date, note FROM transactions ORDER BY date DESC")
    transactions = cursor.fetchall()
    conn.close()

    return render_template("view_transactions.html", transactions=transactions)





# @app.route('/filter_transactions', methods=['GET', 'POST'])
# def filter_transactions():
#     if request.method == 'POST':
#         pass
#     return render_template("filter_transactions.html")

@app.route('/filter_transactions', methods=['GET', 'POST'])
def filter_transactions():
    filtered_transactions = []

    if request.method == 'POST':
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        txn_type = request.form['type']

        query = "SELECT id, type, category, amount, date, note FROM transactions WHERE date BETWEEN ? AND ?"
        params = [start_date, end_date]

        if txn_type != 'all':
            query += " AND type = ?"
            params.append(txn_type)

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()

        # Convert to dicts for Jinja
        filtered_transactions = [
            {
                'id': row[0],
                'type': row[1],
                'category': row[2],
                'amount': row[3],
                'date': row[4],
                'note': row[5]
            }
            for row in rows
        ]

    return render_template("filter_transactions.html", filtered_transactions=filtered_transactions)




@app.route('/search_transaction', methods=['GET'])
def search_transaction():
    keyword = request.args.get('keyword', '')
    results = []  # Dummy result
    return render_template("search_transaction.html", results=results)

@app.route('/expense_dashboard')
def expense_dashboard():
    return render_template("dashboard_expense_income.html")

# Module 3: Budget and Setting alerts

# @app.route('/set_monthly_budget', methods=['GET', 'POST'])
# def set_monthly_budget():
#     if request.method == 'POST':
#         # budget processing logic
#         amount = request.form['amount']
#         category = request.form.get('category', '')
#         month = request.form['month']
#         # Store the data in database (placeholder logic)
#         print(f"Budget Set: {amount} for {category} in {month}")
#     return render_template("set_monthly_budget.html")


@app.route('/set_monthly_budget', methods=['GET', 'POST'])
def set_monthly_budget():
    if request.method == 'POST':
        try:
            amount = float(request.form['amount'])
            category = request.form.get('category', '')
            month = request.form['month']

            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO budgets (category, amount, month)
                VALUES (?, ?, ?)
            """, (category, amount, month))
            conn.commit()
            conn.close()

            return render_template("set_monthly_budget.html", success=True)
        except Exception as e:
            return render_template("set_monthly_budget.html", error=str(e))

    return render_template("set_monthly_budget.html")



# @app.route('/set_category_budget', methods=['GET', 'POST'])
# def set_category_budget():
#     if request.method == 'POST':
#         category = request.form['category']
#         amount = request.form['amount']
#         month = request.form['month']
#         # Placeholder logic to store in DB
#         print(f"Set {category} budget to {amount} for {month}")
#     return render_template("set_category_budget.html")


@app.route('/set_category_budget', methods=['GET', 'POST'])
def set_category_budget():
    if request.method == 'POST':
        try:
            category = request.form['category']
            amount = float(request.form['amount'])
            month = request.form['month']

            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO budgets (category, amount, month)
                VALUES (?, ?, ?)
            """, (category, amount, month))
            conn.commit()
            conn.close()

            return render_template("set_category_budget.html", success=True)
        except Exception as e:
            return render_template("set_category_budget.html", error=str(e))

    return render_template("set_category_budget.html")


# @app.route('/edit_budget', methods=['GET', 'POST'])
# def edit_budget():
#     if request.method == 'POST':
#         category = request.form['category']
#         new_amount = request.form['new_amount']
#         month = request.form['month']
#         # Placeholder logic to update budget in DB
#         print(f"Updated {category} budget to {new_amount} for {month}")
#     return render_template("edit_budget.html")

@app.route('/edit_budget', methods=['GET', 'POST'])
def edit_budget():
    if request.method == 'POST':
        try:
            category = request.form['category']
            new_amount = float(request.form['new_amount'])
            month = request.form['month']

            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()

            # Update the matching budget row
            cursor.execute("""
                UPDATE budgets
                SET amount = ?
                WHERE category = ? AND month = ?
            """, (new_amount, category, month))

            if cursor.rowcount == 0:
                raise ValueError("No matching record found to update.")

            conn.commit()
            conn.close()

            return render_template("edit_budget.html", success=True)
        except Exception as e:
            return render_template("edit_budget.html", error=str(e))

    return render_template("edit_budget.html")



# @app.route('/delete_budget', methods=['GET', 'POST'])
# def delete_budget():
#     if request.method == 'POST':
#         category = request.form['category']
#         month = request.form['month']
#         # Placeholder for deletion logic
#         print(f"Deleted budget for category: {category} in month: {month}")
#     return render_template("delete_budget.html")

@app.route('/delete_budget', methods=['GET', 'POST'])
def delete_budget():
    if request.method == 'POST':
        try:
            category = request.form['category']
            month = request.form['month']

            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()

            cursor.execute("""
                DELETE FROM budgets
                WHERE category = ? AND month = ?
            """, (category, month))

            if cursor.rowcount == 0:
                raise ValueError("No matching budget found to delete.")

            conn.commit()
            conn.close()

            return render_template("delete_budget.html", success=True)
        except Exception as e:
            return render_template("delete_budget.html", error=str(e))

    return render_template("delete_budget.html")




# @app.route('/view_budget_summary', methods=['GET', 'POST'])
# def view_budget_summary():
#     summary = []
#     selected_month = ''
#     if request.method == 'POST':
#         selected_month = request.form['month']
#         # Dummy sample data
#         summary = [
#             {'category': 'Food', 'limit': 10000, 'spent': 9500, 'status': 'OK'},
#             {'category': 'Transport', 'limit': 5000, 'spent': 5200, 'status': 'Exceeded'},
#             {'category': 'Entertainment', 'limit': 3000, 'spent': 1500, 'status': 'OK'},
#         ]
#     return render_template("view_budget_summary.html", summary=summary, selected_month=selected_month)


@app.route('/view_budget_summary', methods=['GET', 'POST'])
def view_budget_summary():
    summary = []
    selected_month = ''

    if request.method == 'POST':
        selected_month = request.form['month']

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Get all budgets for the selected month
        cursor.execute("SELECT category, amount FROM budgets WHERE month = ?", (selected_month,))
        budget_entries = cursor.fetchall()

        for category, limit in budget_entries:
            # Calculate total expense for that category and month
            cursor.execute("""
                SELECT SUM(amount)
                FROM transactions
                WHERE type = 'expense' AND category = ? AND date LIKE ?
            """, (category, f"{selected_month}%"))
            result = cursor.fetchone()
            spent = result[0] if result[0] else 0
            status = "OK" if spent <= limit else "Exceeded"

            summary.append({
                'category': category,
                'limit': limit,
                'spent': spent,
                'status': status
            })

        conn.close()

    return render_template("view_budget_summary.html", summary=summary, selected_month=selected_month)



# Module 10: Feedback and Support
# -------------------- Module 10: Feedback & Support --------------------

@app.route('/submit_feedback', methods=['GET', 'POST'])
def submit_feedback():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        # You can handle saving the feedback to a file, DB, or print/log
        print(f"Feedback received from {name} ({email}): {message}")
        return render_template("submit_feedback.html", success=True)
    
    return render_template("submit_feedback.html", success=False)

@app.route('/faqs')
def view_faq():
    return render_template("view_faq.html")

# @app.route('/contact_support', methods=['GET', 'POST'])
# def contact_support():
#     if request.method == 'POST':
#         # You can later add email logic or store it in the database
#         user_email = request.form['email']
#         subject = request.form['subject']
#         message = request.form['message']
#         # Placeholder: print or log the info
#         print(f"Email from {user_email} - Subject: {subject} - Message: {message}")
#     return render_template("contact_support.html")

@app.route('/contact_support', methods=['GET', 'POST'])
def contact_support():
    if request.method == 'POST':
        user_email = request.form['email']
        subject = request.form['subject']
        message = request.form['message']

        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS support_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT,
                    subject TEXT,
                    message TEXT
                )
            """)
            cursor.execute("INSERT INTO support_requests (email, subject, message) VALUES (?, ?, ?)",
                           (user_email, subject, message))
            conn.commit()
            conn.close()
            return render_template("contact_support.html", success=True)
        except Exception as e:
            return render_template("contact_support.html", error=str(e))

    return render_template("contact_support.html", success=False)


# @app.route('/request_callback', methods=['GET', 'POST'])
# def request_callback():
#     if request.method == 'POST':
#         # Extract form data if needed
#         name = request.form.get('name')
#         phone = request.form.get('phone')
#         time = request.form.get('time')
#         # You could log/store this if connected to DB
#     return render_template("request_callback.html")

@app.route('/request_callback', methods=['GET', 'POST'])
def request_callback():
    if request.method == 'POST':
        try:
            name = request.form['name']
            phone = request.form['phone']
            time = request.form['time']

            # Simulate saving or processing
            print(f"Callback request received: Name={name}, Phone={phone}, Time={time}")

            return render_template("request_callback.html", success=True)
        except Exception as e:
            return render_template("request_callback.html", error=str(e))

    # Initial GET request
    return render_template("request_callback.html")







@app.route('/rate_usability', methods=['GET', 'POST'])
def rate_usability():
    if request.method == 'POST':
        rating = request.form.get('rating')
        comment = request.form.get('comment')
        # Handle or log rating if needed
    return render_template("rate_usability.html")

@app.route('/feedback_dashboard')
def feedback_dashboard():
    return render_template("feedback_dashboard.html")

@app.route('/budget_dashboard')
def budget_dashboard():
    return render_template("dashboard_budget_alerts.html")

# Module 3 Budget Alerts

if __name__ == '__main__':
    app.run(debug=True)
